Decisiones de diseño:
- Como la lista de frutas y verduras solo aparece al momento de seleccionar el tipo de producto,
en la validación solo se corrobora que haya al menos un tipo de producto seleccionado.
